package com.example.pract4;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Картинки-локации и макет первой локации (в нём лежат подсказки)
    private ImageView imgFlight, imgMoon, imgMars;
    private ConstraintLayout layoutEarth;
    private TextView tvCaption;

    // Уведомления
    private NotificationManager notificationManager;
    private static final int NOTIFY_ID = 1;
    private static final String CHANNEL_ID = "cosmo_cat_channel";
    private static final int REQUEST_NOTIFY = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Отступы под строку состояния и панель навигации
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // Находим элементы на экране
        layoutEarth = findViewById(R.id.layoutEarth);
        imgFlight = findViewById(R.id.imageFlight);
        imgMoon = findViewById(R.id.imageMoon);
        imgMars = findViewById(R.id.imageMars);
        tvCaption = findViewById(R.id.tvCaption);

        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createChannelIfNeeded(notificationManager);
        requestNotificationPermission();
    }

    // ---------------- Навигация по локациям ----------------

    public void btnEarthClick(View view) {
        showScene(0);
        sendNotification(R.drawable.ic_rocket, R.string.button_earth, R.string.notify_earth);
    }

    public void btnFlightClick(View view) {
        showScene(1);
        sendNotification(R.drawable.ic_star, R.string.button_flight, R.string.notify_flight);
    }

    public void btnMoonClick(View view) {
        showScene(2);
        sendNotification(R.drawable.ic_moon, R.string.button_moon, R.string.notify_moon);
    }

    public void btnMarsClick(View view) {
        showScene(3);
        sendNotification(R.drawable.ic_planet, R.string.button_mars, R.string.notify_mars);
    }

    // Показывает только одну локацию (0 - Земля, 1 - Полёт, 2 - Луна, 3 - Марс)
    private void showScene(int index) {
        View[] scenes = {layoutEarth, imgFlight, imgMoon, imgMars};
        int[] captions = {R.string.caption_earth, R.string.caption_flight,
                R.string.caption_moon, R.string.caption_mars};

        for (int i = 0; i < scenes.length; i++) {
            scenes[i].setVisibility(i == index ? View.VISIBLE : View.INVISIBLE);
        }
        tvCaption.setText(captions[index]);
    }

    // ---------------- Уведомления ----------------

    // Канал нужен на Android 8+. Для вибрации и звука важность должна быть высокой
    private void createChannelIfNeeded(NotificationManager manager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(getString(R.string.channel_description));
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            manager.createNotificationChannel(channel);
        }
    }

    // На Android 13+ уведомления работают только после разрешения пользователя
    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFY);
        }
    }

    private void sendNotification(int iconRes, int titleRes, int textRes) {
        // По нажатию на уведомление открывается главный экран приложения
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(iconRes)                                  // маленькая иконка
                .setContentTitle(getString(titleRes))                   // заголовок
                .setContentText(getString(textRes))                     // текст
                .setWhen(System.currentTimeMillis())
                .setAutoCancel(true)                                    // исчезает после нажатия
                .setContentIntent(pendingIntent)                        // переход к главному экрану
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)            // звук и вибрация
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);   // видно на экране блокировки

        notificationManager.notify(NOTIFY_ID, builder.build());
    }

    // ---------------- Всплывающие сообщения ----------------

    private void showToast(int textRes) {
        Toast toast = Toast.makeText(getApplicationContext(), textRes, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.BOTTOM, 0, 0);   // внизу экрана
        toast.show();
    }

    public void onCatClick(View view) {
        showToast(R.string.toast_cat);
    }

    public void onRocketClick(View view) {
        showToast(R.string.toast_rocket);
    }

    public void onHouseClick(View view) {
        showToast(R.string.toast_house);
    }

    public void onTreeClick(View view) {
        showToast(R.string.toast_tree);
    }

    public void onSunClick(View view) {
        showToast(R.string.toast_sun);
    }
}
